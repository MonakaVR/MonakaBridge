# Task 4 extraction handoff

This is a reviewed historical migration input, not a second active PICO backend.
Do not launch its legacy service together with Task 2's service: both would own
29765 and could publish duplicate trackers through old/new SteamVR drivers.

The root CMake is a generated, standalone build harness. The source repository's
complete original CMake is preserved at reference/CMakeLists.txt. No PICO private
runtime, Android app, ABI shim, vendor decoder or vendor library is included.
The transport/types closure is migration reference for replacing old consumers;
Task 4 must consume the Task 1 MTP/Observation kit instead of inheriting POTB.

Build without any sibling repository:
  cmake -S . -B build -DPICO_OT_BUILD_TESTS=ON
  cmake --build build --config Debug
  ctest --test-dir build -C Debug --output-on-failure
For Windows x64 driver/calibrator add -DPICO_OT_BUILD_STEAMVR_DRIVER=ON.
The original CMake fetches ValveSoftware/openvr tag v2.15.6. Supply the SDK from
that tag via FETCHCONTENT_SOURCE_DIR_OPENVR_SDK for an offline build. It is not
in this ZIP. Windows SDK/MSVC C++17/CMake >=3.20 are also external prerequisites.
GUI compilation uses .NET Framework 4.8 Developer Pack/WPF and the OS csc.exe.
The GUI script launches after compiling; build/registration do not constitute
hardware validation. Runtime SteamVR/vrpathreg and PICO HMD app installation
are external. start_pico_backend.ps1 is historical launcher reference only.

Task 4 replacement points:
- TrackerDevice::Update and DeviceProvider::receiver_: ReceivedTrackerState,
  PosePacket, POTB Receiver/ClockSync -> Task 1 MtpPose/MtpTrackerState adapter.
- PicoOutputAToOpenVrCandidate/world/mount transforms -> owned mapping and
  calibration profiles; do not apply both here and upstream.
- tools/pc_bridge_service.cpp routing/Utility fan-out -> common Bridge policy;
  replace POTB Publisher/ToTrackerState with the supplied common codec.
- service_contract.hpp, output_route_ipc.hpp, world_alignment_ipc.hpp, C# IPC
  declarations: version and migrate routing/alignment configuration together.
- integrations/monaka and receiver_c_api remain legacy until Task 5 confirms
  no active consumer needs them. Do not confuse this with the Backend C API.
- scripts/Start_* paths and process names require new Bridge artifact names;
  ensure_pc_runtime.ps1 must stop owning/starting the PICO HMD lifecycle.

The supplied config examples were generated from service_contract.hpp and
SaveAlignmentConfig in steamvr_control_wpf.cs. They are not a user's config.
Original locations: %LOCALAPPDATA%/PicoMotionTrackerBridge/output_route.txt and
steamvr_alignment.json. Read version 1 translation fields before importing;
never silently reuse transforms for an unrelated C1 space id/revision.

No root LICENSE/NOTICE was present at the reviewed base. Original file notices
are preserved verbatim; this export grants no new license. OpenVR is external
and its license must accompany redistributed SDK parts. The manifest explicitly
records the origin and SHA of every original file and labels generated files.

Historical docs may describe pre-SteamVR backend milestones. Current Task 2
retains the old driver/GUI only as Phase A compatibility. Phase B removal needs
Task 4 Direct regression and Task 5 MTP/C ABI retirement handoffs.
